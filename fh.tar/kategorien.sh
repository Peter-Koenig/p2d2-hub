cat > src/content/kategorien/friedhoefe.md <<EOF
---
title: Friedhöfe
icon: friedhof
order: 1
---
Daten und Standorte öffentlicher Friedhöfe in deiner Stadt.
EOF

cat > src/content/kategorien/blumenbeete.md <<EOF
---
title: Blumenbeete
icon: blumenbeet
order: 2
---
Informationen zu gepflegten Blumenbeeten und Grünanlagen.
EOF

cat > src/content/kategorien/strassenlaternen.md <<EOF
---
title: Straßenlaternen
icon: laternen
order: 3
---
Übersicht der Straßenbeleuchtung und ihrer Wartung.
EOF
