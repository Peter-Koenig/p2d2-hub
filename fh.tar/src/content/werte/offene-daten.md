---
title: Offene Daten
icon: offene-daten
order: 3
---
Alle gesammelten Daten sind frei verfügbar und können von jeder Person genutzt, geteilt und verbessert werden.
