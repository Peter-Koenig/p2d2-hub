---
title: Transparenz
icon: transparenz
order: 1
---
Wir fördern Offenheit und Nachvollziehbarkeit in der Verwaltung, damit alle Bürger:innen Zugang zu wichtigen Informationen haben.
