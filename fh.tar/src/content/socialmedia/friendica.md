---
name: Friendica
url: https://friendica.example.org/profile/publicdata
icon: friendica
---
