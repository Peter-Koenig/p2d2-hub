---
name: Mastodon
url: https://mastodon.social/@publicdata
icon: mastodon
---
