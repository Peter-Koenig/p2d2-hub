---
name: Pixelfed
url: https://pixelfed.example.org/publicdata
icon: pixelfed
---
