# Erfassen wir den öffentlichen Datenraum</br> <span style="color:#41C7B4;"> der für uns Freiheit und Souveränität bedeutet</span>
