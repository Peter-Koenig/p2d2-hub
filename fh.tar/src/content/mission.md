# Transparenz

Wir machen Verwaltungsdaten transparent und für alle zugänglich, um eine offene Gesellschaft zu fördern und Vertrauen zu schaffen.
