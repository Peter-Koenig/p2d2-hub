---
name: openCode.de
url: https://opencode.de/publicdata
---
